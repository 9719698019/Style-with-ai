
function generateOutfit() {
    const result = document.getElementById("result");
    result.innerHTML = "<p>Generating outfit using AI...</p><img src='https://via.placeholder.com/200x300?text=AI+Outfit' alt='AI Outfit'/>";

    // Add affiliate buttons
    setTimeout(() => {
        result.innerHTML += `
            <div style='margin-top: 20px;'>
                <a href='https://www.meesho.com/' target='_blank'>Buy on Meesho</a> |
                <a href='https://www.amazon.in/' target='_blank'>Buy on Amazon</a> |
                <a href='https://www.flipkart.com/' target='_blank'>Buy on Flipkart</a>
            </div>`;
    }, 2000);
}
